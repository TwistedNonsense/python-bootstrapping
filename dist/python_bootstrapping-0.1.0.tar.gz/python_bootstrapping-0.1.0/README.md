# Project Bootstrap Helper

Bootstrap any Python project with a consistent `.venv`:

- Creates or refreshes `.venv` automatically
- Upgrades `pip/setuptools/wheel`
- Reinstalls when `requirements.txt` / `pyproject.toml` or other watched files change
- Supports pinned Python version via `PYTHON_VERSION` or `.python-version`
- Run projects with a single command: `bootstrap-run`


## Installation

Clone this repository or install via pip (when published to PyPI):

```bash
git clone https://github.com/TwistedNonsense/python-bootstrapping.git
cd python-bootstrapping
pip install -e .
```

This makes the `bootstrap-run` command available system-wide.

## Usage

From any project directory (containing `requirements.txt` or `pyproject.toml`):

```bash
bootstrap-run
```

On first run this will:

- Create `.venv` if it doesn’t exist
- Install/upgrade `pip`, `setuptools`, `wheel`
- Install dependencies from `requirements.txt` (or `pyproject.toml`)
- Save environment state to `.venv/.env_state.json`

### Example usage

```bash
export APP_FACTORY="myapp:create_app"
bootstrap-run
```

or

```bash
export APP_CMD="flask run"
bootstrap-run
```

or run any explicit command inside the bootstrapped environment:

```bash
bootstrap-run python -m pytest -q
```

## Configuration

- `APP_FACTORY="pkg.module:create_app"`  
  Import a Flask app factory and run it.

- `APP_CMD="flask run"`  
  Run an arbitrary shell command inside the environment.

- `PYTHON_VERSION="3.12"` or a `.python-version` file  
  Forces a specific Python version for the venv.

- `BOOTSTRAP_WATCH="requirements.txt,pyproject.toml,src/**.py"`  
  Override the list of files that trigger reinstall.

## Optional ignores

Add file/directory patterns to `.bootstrapignore` to prevent unnecessary
reinstalls when unrelated files change.

Example `.bootstrapignore`:

```
.git/**
**/__pycache__/**
node_modules/**
```

## Development

Build and test locally:

```bash
python -m pip install --upgrade pip build
python -m build
python -m pip install -e .
bootstrap-run --help
```

## Notes

- Works on macOS, Linux, Windows
- No shell scripts required
- Idempotent: reuses `.venv` unless dependencies change

## License

MIT
